// Command proxy: this command's implementation remains in its original plugin,
// while this per-command file is the command-folder entry point.
const registry = require('../arslan');
const original = registry.findCommand('kiss');
if (original) {
  const info = { ...original, pattern: 'kiss', filename: __filename };
  registry.cmd(info, (...args) => original.function(...args));
}
module.exports = original;
