const { cmd } = require('../arslan');
const flow = require('../lib/flows/sm');
cmd({ pattern: 'sm', alias: ['scheduledmessage', 'schedulemsg'], desc: 'Guided scheduled message setup', category: 'automation', ownerOnly: true, react: '🗓️', filename: __filename }, async (conn, mek, m, ctx) => flow(conn, ctx.from, mek, ctx.isOwner, ctx.args || [], ctx.botNumber));
module.exports = flow;
