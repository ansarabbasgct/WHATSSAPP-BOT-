const { cmd } = require('../arslan');
const fs = require('fs-extra');
const config = require('../config');
cmd({ pattern: 'sticker', alias: ['s'], desc: 'Image or video ko sticker mein convert karo', category: 'tools', react: '🖼️', use: '.sticker (image/video par reply)', filename: __filename }, async (conn, mek, m, ctx) => {
  const quoted = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const img = quoted?.imageMessage || mek.message?.imageMessage;
  const vid = quoted?.videoMessage || mek.message?.videoMessage;
  if (!img && !vid) return ctx.reply('❌ Image ya video par reply karke .sticker likhein.');
  try {
    const { Sticker, StickerTypes } = require('wa-sticker-formatter');
    const media = img ? { msg: img, mtype: 'imageMessage' } : { msg: vid, mtype: 'videoMessage' };
    const file = await conn.downloadAndSaveMediaMessage(media, `./tmp/genz_sticker_${Date.now()}`);
    const out = await new Sticker(file, { pack: (ctx.q || config.BOT_NAME || 'GEN Z WhatsApp Bot').slice(0, 30), author: config.BOT_NAME || 'GEN Z WhatsApp Bot', type: StickerTypes.FULL, quality: 80 }).toBuffer();
    await conn.sendMessage(ctx.from, { sticker: out }, { quoted: mek }); await fs.remove(file).catch(() => {});
  } catch (e) { return ctx.reply('❌ Sticker nahi bana: ' + e.message); }
});
