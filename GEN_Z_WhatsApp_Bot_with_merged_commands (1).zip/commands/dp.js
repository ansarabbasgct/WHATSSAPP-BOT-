const { cmd } = require('../arslan');
const flow = require('../lib/flows/dp');
cmd({ pattern: 'dp', alias: ['profilepic', 'ppview'], desc: 'Download a WhatsApp profile picture', category: 'tools', react: '🖼️', filename: __filename }, async (conn, mek, m, ctx) => flow(conn, ctx.from, mek, ctx.q || ''));
module.exports = flow;
