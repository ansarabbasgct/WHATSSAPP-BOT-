// Load every command entry from commands/<command>.js. There is intentionally
// no commands/index.js: each file in the folder represents one command.
const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '..', 'commands');
for (const file of fs.readdirSync(dir).filter(name => name.endsWith('.js')).sort()) {
  try { require(path.join(dir, file)); } catch (e) { console.error(`[COMMANDS] Failed to load ${file}:`, e.message); }
}
